// Declaro a funcion sumar y paso como parametro 2 numeros
function sumar(num1, num2){
    resultado=num1+num2;
    console.log("La suma es"+resultado);
}
// Declaro la explotacion de la funcion 
module.exports = {
    "sumar": sumar
}