const cantidad = (prompt("Ingresar cantidad de notas "));
let promedio = 0;
let calificacion= 0;
for ( let i = 0; i <cantidad.length(); i++){
    suma = prompt("Ingresar notas " (i+1))
    suma2= suma2 + suma
}
promedio = (suma2 / cantidad);
document.write("El promedio es " + promedio);