var num = prompt("Ingresar un numero entero");
var resultado = 1;
for(var i = 1; i<=num; i++){
    resultado=resultado*i;
}
alert (`El factorial del numero ${num} es ${resultado}`);