function aleatorio (min){
    var numero = Math.round((Math.random() *100) );
    return numero;
}
// Funcion que genera un numero
var numeros = new Array();
var temp = 0;
var copia = true;
var j = 0;
// creamos un array
for (var i = 0; i<100; i++){
    do{
        j = 0;
        copia = true;
        temp = aleatorio(0,100);
        for( var j=0; j<numeros.length; j++){
            if(temp==numeros[j]) {
                copia = false;
            }
        }
    }while(copia==false);
    numeros[i] = temp;
}
var cont = 0;
for(var i=0; i < numeros.length; i++){
    document.write("" + numeros[i] + "<br>");
    cont++;
}