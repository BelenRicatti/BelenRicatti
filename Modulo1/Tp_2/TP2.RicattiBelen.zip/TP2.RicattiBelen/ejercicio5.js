var texto = prompt ("Ingrese un texto")

function analizar_texto(texto) {
    if (texto === texto.toUpperCase()) {
        return "El texto contiene mayusculas";
    } else if (texto === texto.toLowerCase()) {
        return "El texto contiene minusculas";
    } else {
        return "El texto contiene mayusculas y minusculas";
    }
}
document.write(analizar_texto(texto))
//Cree una funcion que analiza primero si tiene solo mayusculas,
//si no analiza si tiene solo minusculas, y por ultimo si contiene
//los dos y los muestra por pantalla.