var vocales = [ "a", "e", "i", "o", "u"];
// Declaro el array de vocales
var texto = prompt("Introducir texto");
// Pedir ingresar el texto
var textominuscula = texto.toLowerCase();
// Pasamos el texto en minuscula
var posicion = 0;
// aca guardamos la posicion de la vocal
var stop = false;
// declaramos una bandera
for (var i = 0; i < textominuscula.length; i++) {
// recorremos el texto
    for ( var j = 0 ; j < vocales.length; j++) {
        // recorremos el array de vocales
        if (vocales [j] == textominuscula.charAt(i)){
            // si encuentra la vocal se guarda
            posicion = i;
            stop = true;
            // con la bandera cortamos el bucle
            break;
        }
    }
    if (stop){
        break;
    }
}
document.write("La primera vocal esta en la posicion " + posicion);
// No se como haces para que me muestra "La "a" es la prmera vocal"
//  lo probe de muchas maneras y no me salio :c