var valores = [true, false, 2, "hola", "mundo", 3, "char"];
let mayor = "";

for (const dato of valores) {
    if (dato.length > mayor.length) {
        mayor = dato;
    }
}
    
document.write (`El texto con mas letras es "${mayor}" <br/>`);
//Se busca el texto mas largo y lo imprimo en pantalla//

palabras=valores.filter(dato => typeof (dato) == "string");
document.write ((`Las palabras de manor a mayor son `), palabras.sort(), (`<br/>`));
//Se filtran las palabras y las imprimo de menor a mayor//

numero=valores.filter(dato=>typeof (dato) == "number");
suma=numero[0]+numero[1];
resta=numero[0]-numero[1];
mul=numero[0]*numero[1];
div=numero[0]/numero[1];
document.write (`La suma de los numeros es = ${suma} <br/>`);
document.write (`La resta de los numeros es = ${resta} <br/>`);
document.write (`La multiplicacion de los numeros es = ${mul} <br/>`);
document.write (`La division de los numeros es = ${div} <br/>`);
//Cree un nuevo array "numero" y realice las operaciones de esta manera (luego las imprimi)//
//Estoy contenta por que me salio a la primera jaja espero que este bien//