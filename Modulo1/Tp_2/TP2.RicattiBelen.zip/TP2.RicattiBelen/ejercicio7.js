var texto = prompt ("Introducir texto");
// pido que ingresen un texto
function voltear(texto){
    // Creo una funcion
    var caracter = "";
    var salida = "";
    // declaro variables donde se guardara la informacion
    for(var i = 0; i < texto.length; i++){
        // recorremos el texto
        caracter = texto.charAt(i);
        salida = caracter + salida;
    }
    return salida;
}
var reves = voltear(texto);
document.write("El texto ingresado al reves es " + reves);