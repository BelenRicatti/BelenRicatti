var mes = prompt("Ingrese un mes ")
function analizarMes(mes){
   if (mes === enero){
    return "Enero tiene 31 dias"
   } else if (mes === febrero){
    return "Febrero tiene 28 dias"
   }
   
   }
document.write(analizarMes(mes))
// Profe el 9 y el 10 no me salio, le dejo mis machetes 
// pero se que estan mal, le prometo que lo voy a volver a hacer
// hasta que me salga.